import React from 'react'

const Error = () => {
    return (
        <>
            <div className='container-error'>Lo siento, vuelvaa intentarlo. </div>
        </>
    );
};

export default Error;