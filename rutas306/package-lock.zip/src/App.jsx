import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Inicio from './componentes/Inicio.jsx';
import Contacto from './componentes/Contacto.jsx';
import AcercaDe from './componentes/Acercade.jsx';
import Productos from './componentes/Productos.jsx';
import Menu from './componentes/Menu.jsx';  // Importamos el componente Menu
import Error from './componentes/Error.jsx';

function App() {
  return (
    <BrowserRouter>
      {/* Colocamos el menú aquí para que aparezca en todas las páginas */}
      <Menu />

      <Routes>
        <Route path="/" element={<Inicio />} />
        <Route path="/contacto" element={<Contacto />} />
        <Route path="/acercade" element={<AcercaDe />} />
        <Route path="/productos" element={<Productos />} />
        <Route path="*" element={<Error />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
