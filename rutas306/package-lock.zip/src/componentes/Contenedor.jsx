import React from 'react'

const Contenedor = () => {
  return (
    <div className='contenedor-contenedor'>

    </div>
  )
}

export default Contenedor;