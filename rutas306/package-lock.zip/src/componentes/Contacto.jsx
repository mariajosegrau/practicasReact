import {useNavigate} from 'react-router-dom';

const Contacto = () => {

    const navigate = useNavigate();

    const irInicio = () => {
        navigate('/');
    }
    return (
      <div>
        <h1>Contacto</h1>
        <p>Si tienes alguna pregunta, contacta con nosotros en: contacto@ejemplo.com</p>
        <button onClick={irInicio} className='boton-inicio' >Ir a Inicio</button>
      </div>
    );
  };

export default Contacto;